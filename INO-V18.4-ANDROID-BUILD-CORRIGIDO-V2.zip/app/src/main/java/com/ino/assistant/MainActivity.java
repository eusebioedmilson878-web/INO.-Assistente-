package com.ino.assistant;

import android.Manifest;
import android.app.Activity;
import android.content.*;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.*;
import android.provider.ContactsContract;
import android.provider.Settings;
import android.provider.MediaStore;
import android.media.MediaPlayer;
import android.content.pm.ResolveInfo;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.view.accessibility.AccessibilityNodeInfo;
import android.content.BroadcastReceiver;
import android.content.IntentFilter;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.net.URLEncoder;
import java.util.*;
import org.json.*;

public class MainActivity extends Activity {
    WebView web; TextToSpeech tts; SpeechRecognizer speech;
    static final int REQ_CONTACTS=10, REQ_CAMERA=13, REQ_AUDIO=14, REQ_MEDIA=15, REQ_SMS=16;
    static final int REQ_MEDIA_IMAGES=17, REQ_MEDIA_VIDEO=18;
    MediaPlayer mediaPlayer;
    String pendingPermissionAction="";
    BroadcastReceiver bubbleReceiver;

    @Override public void onCreate(Bundle b){
        super.onCreate(b); web=new WebView(this); setContentView(web); configure();
        tts=new TextToSpeech(this,status->{ if(status==TextToSpeech.SUCCESS){ tts.setOnUtteranceProgressListener(new UtteranceProgressListener(){ public void onStart(String id){ notifySpeech("start"); } public void onDone(String id){ notifySpeech("done"); } public void onError(String id){ notifySpeech("error"); } }); } });
        registerBubbleReceiver();
        handleAuthIntent(getIntent());
        if(Build.VERSION.SDK_INT>=33) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},99);
    }

    void configure(){
        WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setMediaPlaybackRequiresUserGesture(false); s.setAllowFileAccess(true); s.setAllowContentAccess(true);
        web.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView v, android.webkit.WebResourceRequest r){ String u=r.getUrl().toString(); if(u.startsWith("file:")) return false; openUrl(u); return true; }
            @Override public void onPageFinished(WebView v,String url){
                String ep=BuildConfig.INO_RESEARCH_ENDPOINT;
                if(ep!=null && !ep.isEmpty()) v.evaluateJavascript("localStorage.setItem('ino_research_endpoint',"+JSONObject.quote(ep)+");",null);
            }
        });
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new AndroidInterface(this),"AndroidInterface");
        web.loadUrl("file:///android_asset/ino.html");
    }

    void registerBubbleReceiver(){
        bubbleReceiver=new BroadcastReceiver(){
            @Override public void onReceive(Context c,Intent i){
                String action=i.getAction();
                if("INO_BUBBLE_COMMAND".equals(action)){
                    String text=i.getStringExtra("text");
                    runUi(()->web.evaluateJavascript("if(window.inoBubbleCommand) window.inoBubbleCommand("+JSONObject.quote(text==null?"":text)+");",null));
                } else if("INO_BUBBLE_WAKE".equals(action)){
                    runUi(()->web.evaluateJavascript("if(window.inoBubbleCommand) window.inoBubbleCommand('');",null));
                } else if("INO_BUBBLE_SETTING".equals(action)){
                    String key=i.getStringExtra("key"), value=i.getStringExtra("value");
                    if("speech_rate".equals(key)){ getPreferences(0).edit().putString("speech_rate",value).apply(); }
                    final String k=key==null?"":key, v=value==null?"":value;
                    runUi(()->web.evaluateJavascript("if(window.inoBubbleSetting) window.inoBubbleSetting("+JSONObject.quote(k)+","+JSONObject.quote(v)+");",null));
                }
            }
        };
        IntentFilter f=new IntentFilter(); f.addAction("INO_BUBBLE_COMMAND"); f.addAction("INO_BUBBLE_WAKE"); f.addAction("INO_BUBBLE_SETTING");
        if(Build.VERSION.SDK_INT>=33) registerReceiver(bubbleReceiver,f,Context.RECEIVER_NOT_EXPORTED); else registerReceiver(bubbleReceiver,f);
    }
    void bubbleState(String state){
        Intent i=new Intent("INO_BUBBLE_STATE"); i.setPackage(getPackageName()); i.putExtra("state",state); sendBroadcast(i);
    }
    @Override protected void onNewIntent(Intent intent){ super.onNewIntent(intent); handleAuthIntent(intent); }
    void handleAuthIntent(Intent intent){
        if(intent==null || intent.getData()==null || !"ino".equalsIgnoreCase(intent.getData().getScheme())) return;
        if("auth".equalsIgnoreCase(intent.getData().getHost())){ String token=intent.getData().getQueryParameter("token"); if(token!=null&&!token.isEmpty()) runUi(()->web.evaluateJavascript("if(window.inoGoogleToken) window.inoGoogleToken("+JSONObject.quote(token)+");",null)); }
    }

    @Override protected void onDestroy(){
        if(bubbleReceiver!=null){try{unregisterReceiver(bubbleReceiver);}catch(Exception ignored){}}
        stopSpeechRecognizer();
        if(mediaPlayer!=null){try{mediaPlayer.release();}catch(Exception ignored){} mediaPlayer=null;}
        if(tts!=null){try{tts.stop();tts.shutdown();}catch(Exception ignored){}}
        super.onDestroy();
    }

    public void openUrl(String url){ runUi(()->{ try{ startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url))); }catch(Exception ignored){} }); }
    void runUi(Runnable r){ if(Looper.myLooper()==Looper.getMainLooper()) r.run(); else runOnUiThread(r); }

    static String norm(String s){
        if(s==null) return "";
        return java.text.Normalizer.normalize(s.toLowerCase(Locale.ROOT), java.text.Normalizer.Form.NFD)
                .replaceAll("\\p{M}+", "").replaceAll("[^a-z0-9]+", " ").trim().replaceAll("\\s+"," ");
    }

    List<ResolveInfo> launcherApps(){
        Intent launcher=new Intent(Intent.ACTION_MAIN);
        launcher.addCategory(Intent.CATEGORY_LAUNCHER);
        return getPackageManager().queryIntentActivities(launcher, PackageManager.MATCH_ALL);
    }

    String labelOf(ResolveInfo ri){ CharSequence x=ri.loadLabel(getPackageManager()); return x==null?ri.activityInfo.packageName:x.toString(); }

    int levenshtein(String a,String b){
        int[] prev=new int[b.length()+1], cur=new int[b.length()+1];
        for(int j=0;j<=b.length();j++) prev[j]=j;
        for(int i=1;i<=a.length();i++){
            cur[0]=i;
            for(int j=1;j<=b.length();j++) cur[j]=Math.min(Math.min(cur[j-1]+1,prev[j]+1),prev[j-1]+(a.charAt(i-1)==b.charAt(j-1)?0:1));
            int[] t=prev; prev=cur; cur=t;
        }
        return prev[b.length()];
    }

    ResolveInfo resolveInstalledApp(String requested){
        String q=norm(requested);
        if(q.isEmpty()) return null;
        ResolveInfo exact=null, best=null; int bestScore=0; int bestDistance=Integer.MAX_VALUE;
        for(ResolveInfo ri:launcherApps()){
            String label=norm(labelOf(ri));
            if(label.equals(q)){ exact=ri; break; }
            int score=0;
            if(label.startsWith(q) || q.startsWith(label)) score=82;
            String[] qt=q.split(" "); String[] lt=label.split(" ");
            int hits=0; for(String x:qt) for(String y:lt) if(x.equals(y) || (x.length()>=4 && y.startsWith(x))){hits++;break;}
            if(hits>0) score=Math.max(score,45+hits*12);
            int d=levenshtein(q,label); int max=Math.max(q.length(),label.length());
            if(max>0 && d<=Math.max(1,max/3)) score=Math.max(score,100-(d*100/max));
            if(score>bestScore || (score==bestScore && d<bestDistance)){bestScore=score;best=ri;bestDistance=d;}
        }
        return exact!=null?exact:(bestScore>=68?best:null);
    }

    public boolean openPlayStoreSearch(String q){
        try{
            Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse("market://search?q="+Uri.encode(q==null?"":q)));
            i.setPackage("com.android.vending");
            runUi(()->{try{startActivity(i);}catch(Exception ignored){}});
            return true;
        }catch(Exception e){return false;}
    }

    public boolean launchApp(String app,String extra){
        final String requested=app==null?"":app.trim();
        if(requested.isEmpty()) return false;
        ResolveInfo ri=resolveInstalledApp(requested);
        if(ri!=null){
            try{
                Intent i=new Intent(Intent.ACTION_MAIN); i.addCategory(Intent.CATEGORY_LAUNCHER);
                i.setClassName(ri.activityInfo.packageName,ri.activityInfo.name);
                JSONObject payload=null; try{payload=extra==null?null:new JSONObject(extra);}catch(Exception ignored){}
                String query=payload==null?"":payload.optString("query","");
                String op=payload==null?"":payload.optString("operation","");
                if("PESQUISAR".equalsIgnoreCase(op) && !query.isEmpty()){
                    String label=norm(labelOf(ri));
                    if(label.contains("youtube")) { i=new Intent(Intent.ACTION_VIEW,Uri.parse("https://www.youtube.com/results?search_query="+Uri.encode(query))); i.setPackage(ri.activityInfo.packageName); }
                    else if(label.contains("spotify")) { i=new Intent(Intent.ACTION_VIEW,Uri.parse("spotify:search:"+Uri.encode(query))); i.setPackage(ri.activityInfo.packageName); }
                    else if(label.contains("play store")||label.contains("google play")) { return openPlayStoreSearch(query); }
                }
                final Intent launch=i; runUi(()->{try{startActivity(launch);}catch(Exception ignored){}}); return true;
            }catch(Exception ignored){}
        }
        String q=norm(requested);
        String url="";
        if(q.equals("google")) url="https://www.google.com/";
        else if(q.equals("gmail")) url="https://mail.google.com/";
        else if(q.equals("chatgpt")||q.equals("chat gpt")) url="https://chatgpt.com/";
        else if(q.equals("claude")) url="https://claude.ai/";
        if(!url.isEmpty()){openUrl(url);return true;}
        return false;
    }

    @JavascriptInterface public String getInstalledApps(){
        JSONArray arr=new JSONArray(); LinkedHashSet<String> seen=new LinkedHashSet<>();
        try{ for(ResolveInfo ri:launcherApps()){
            String pkg=ri.activityInfo.packageName; if(!seen.add(pkg)) continue;
            JSONObject o=new JSONObject(); o.put("name",labelOf(ri)); o.put("package",pkg); arr.put(o);
        }}catch(Exception ignored){} return arr.toString();
    }

    String findLocalMusic(String query){
        if(checkSelfPermission(Build.VERSION.SDK_INT>=33?Manifest.permission.READ_MEDIA_AUDIO:Manifest.permission.READ_EXTERNAL_STORAGE)!=PackageManager.PERMISSION_GRANTED){
            return "{\"status\":\"PERMISSION_REQUIRED\"}";
        }
        try{
            String q=norm(query);
            String[] projection={MediaStore.Audio.Media._ID,MediaStore.Audio.Media.TITLE,MediaStore.Audio.Media.ARTIST};
            try(android.database.Cursor c=getContentResolver().query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,projection,null,null,MediaStore.Audio.Media.TITLE+" ASC")){
                if(c==null) return "{\"status\":\"NOT_FOUND\"}";
                ArrayList<JSONObject> candidates=new ArrayList<>();
                while(c.moveToNext()){
                    String title=c.getString(1), artist=c.getString(2);
                    String both=norm((title==null?"":title)+" "+(artist==null?"":artist));
                    int score=0;
                    for(String token:q.split(" ")) if(token.length()>2 && both.contains(token)) score+=20;
                    if(norm(title).equals(q)) score+=120;
                    if(artist!=null && !norm(artist).isEmpty() && q.contains(norm(artist))) score+=60;
                    if(score>=20){
                        JSONObject o=new JSONObject(); o.put("id",c.getString(0)); o.put("title",title==null?"":title); o.put("artist",artist==null?"":artist); o.put("score",score); candidates.add(o);
                    }
                }
                candidates.sort((x,y)->y.optInt("score")-x.optInt("score"));
                JSONObject out=new JSONObject();
                if(candidates.isEmpty()){out.put("status","NOT_FOUND"); return out.toString();}
                // Never silently choose between close candidates.
                if(candidates.size()>1 && candidates.get(0).optInt("score") < candidates.get(1).optInt("score")+20){
                    out.put("status","AMBIGUOUS"); JSONArray a=new JSONArray(); for(int i=0;i<Math.min(5,candidates.size());i++) a.put(candidates.get(i)); out.put("candidates",a); return out.toString();
                }
                JSONObject best=candidates.get(0);
                Uri uri=Uri.withAppendedPath(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,best.getString("id"));
                try{
                    if(mediaPlayer!=null){mediaPlayer.release();mediaPlayer=null;}
                    mediaPlayer=new MediaPlayer(); mediaPlayer.setDataSource(this,uri); mediaPlayer.setOnPreparedListener(MediaPlayer::start); mediaPlayer.prepareAsync();
                    out.put("status","PLAYING"); out.put("title",best.optString("title")); out.put("artist",best.optString("artist")); return out.toString();
                }catch(Exception e){out.put("status","FAILED"); out.put("error","media"); return out.toString();}
            }
        }catch(Exception e){return "{\"status\":\"FAILED\"}";}
    }

    boolean playLocalMusic(String query){
        String result=findLocalMusic(query);
        return result.contains("\"status\":\"PLAYING\"");
    }

    String findAndOpenFile(String name){
        String wanted=norm(name);
        if(wanted.isEmpty()) return "{\"status\":\"NOT_FOUND\"}";
        try{
            String[] projection={MediaStore.Files.FileColumns._ID,MediaStore.Files.FileColumns.DISPLAY_NAME,MediaStore.Files.FileColumns.MIME_TYPE,MediaStore.Files.FileColumns.MEDIA_TYPE};
            try(android.database.Cursor c=getContentResolver().query(MediaStore.Files.getContentUri("external"),projection,null,null,MediaStore.Files.FileColumns.DISPLAY_NAME+" ASC")){
                if(c==null) return "{\"status\":\"NOT_FOUND\"}";
                String exactUri=null, exactName=null, mime="*/*"; ArrayList<String[]> near=new ArrayList<>();
                while(c.moveToNext()){
                    String display=c.getString(1); if(display==null) continue;
                    String dn=norm(display);
                    if(dn.equals(wanted)){exactUri=ContentUris.withAppendedId(MediaStore.Files.getContentUri("external"),c.getLong(0)).toString(); exactName=display; mime=c.getString(2); break;}
                    if(dn.contains(wanted) || wanted.contains(dn)) near.add(new String[]{display,String.valueOf(c.getLong(0)),c.getString(2)});
                }
                JSONObject out=new JSONObject();
                if(exactUri!=null){
                    final String u=exactUri, m=mime==null?"*/*":mime;
                    runUi(()->{try{Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse(u));i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);if(m!=null&&!m.isEmpty())i.setType(m);startActivity(i);}catch(Exception ignored){}});
                    out.put("status","OPENED");out.put("name",exactName);return out.toString();
                }
                if(near.size()>1){out.put("status","AMBIGUOUS");JSONArray a=new JSONArray();for(int i=0;i<Math.min(5,near.size());i++)a.put(near.get(i)[0]);out.put("candidates",a);return out.toString();}
                out.put("status","NOT_FOUND");return out.toString();
            }
        }catch(Exception e){return "{\"status\":\"FAILED\"}";}
    }

    String moveMediaFile(String name,String folder){
        if(Build.VERSION.SDK_INT<29) return "{\"status\":\"UNSUPPORTED\"}";
        String wanted=norm(name), dest=(folder==null?"":folder).trim(); if(wanted.isEmpty()||dest.isEmpty()) return "{\"status\":\"INVALID\"}";
        try{
            Uri base=MediaStore.Files.getContentUri("external");
            String[] projection={MediaStore.Files.FileColumns._ID,MediaStore.Files.FileColumns.DISPLAY_NAME,MediaStore.Files.FileColumns.RELATIVE_PATH};
            try(android.database.Cursor c=getContentResolver().query(base,projection,null,null,null)){
                if(c==null)return "{\"status\":\"NOT_FOUND\"}";
                long id=-1;String display=null;
                while(c.moveToNext()){String d=c.getString(1);if(d!=null&&norm(d).equals(wanted)){id=c.getLong(0);display=d;break;}}
                if(id<0)return "{\"status\":\"NOT_FOUND\"}";
                Uri u=ContentUris.withAppendedId(base,id); ContentValues v=new ContentValues(); v.put(MediaStore.Files.FileColumns.RELATIVE_PATH,"Download/"+dest+"/"); int n=getContentResolver().update(u,v,null,null); return n>0?"{\"status\":\"MOVED\"}":"{\"status\":\"FAILED\"}";
            }
        }catch(Exception e){return "{\"status\":\"FAILED\"}";}
    }

    String findContactNumber(String requested){
        if(requested==null||requested.trim().isEmpty()) return "";
        if(checkSelfPermission(Manifest.permission.READ_CONTACTS)!=PackageManager.PERMISSION_GRANTED) return "";
        String q=norm(requested); String best=""; int bestScore=0;
        try(android.database.Cursor c=getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,new String[]{ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,ContactsContract.CommonDataKinds.Phone.NUMBER},null,null,null)){
            if(c!=null) while(c.moveToNext()){
                String name=c.getString(0), number=c.getString(1); if(name==null||number==null)continue;
                String n=norm(name); int score=0; if(n.equals(q))score=100; else if(n.startsWith(q)||q.startsWith(n))score=80; else for(String part:n.split(" ")) if(part.equals(q))score=Math.max(score,75);
                if(score>bestScore){bestScore=score;best=number;}
            }
        }catch(Exception ignored){}
        return bestScore>=70?best:"";
    }

    boolean openWhatsAppAndSend(String number,String message){
        try{
            String digits=new AndroidInterface(this).normalizeInternationalNumber(number);
            if(digits.length()<7)return false;
            Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse("https://wa.me/"+digits+"?text="+URLEncoder.encode(message==null?"":""+message,"UTF-8")));
            i.setPackage("com.whatsapp"); final Intent launch=i; runUi(()->{try{startActivity(launch);}catch(Exception ignored){}}); return true;
        }catch(Exception e){return false;}
    }

    boolean sendSmsDirect(String number,String message){
        if(checkSelfPermission(Manifest.permission.SEND_SMS)!=PackageManager.PERMISSION_GRANTED){
            getPreferences(0).edit().putString("pending_sms_number",number==null?"":number).putString("pending_sms_text",message==null?"":message).apply();
            runOnUiThread(()->requestPermissions(new String[]{Manifest.permission.SEND_SMS},REQ_SMS));
            return true;
        }
        try{ android.telephony.SmsManager.getDefault().sendTextMessage(number,null,message,null,null); return true; }catch(Exception e){ return false; }
    }


    boolean accessibilityEnabled(){ return InoAccessibilityService.isEnabled(); }
    void requestAccessibility(){ try{startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));}catch(Exception ignored){} }
    String executeAccessibilityAction(String action,String packageName,String query,String contact,String message){
        JSONObject out=new JSONObject(); try{
            if(!accessibilityEnabled()){out.put("status","NEEDS_ACCESSIBILITY");return out.toString();}
            boolean ok=InoAccessibilityService.execute(action,packageName,query,contact,message);
            out.put("status",ok?"REQUESTED":"FAILED"); return out.toString();
        }catch(Exception e){try{out.put("status","FAILED");}catch(Exception ignored){}return out.toString();}
    }

    void openCameraNow(){ try{Intent i=new Intent("android.media.action.IMAGE_CAPTURE"); startActivity(i);}catch(Exception ignored){} }
    void notifyPermission(String name){ runUi(()->web.evaluateJavascript("if(window.inoNativePermissionGranted) window.inoNativePermissionGranted("+JSONObject.quote(name)+");",null)); }
    void notifySpeech(String state){ bubbleState(state); runUi(()->web.evaluateJavascript("if(window.inoNativeSpeechState) window.inoNativeSpeechState("+JSONObject.quote(state)+");",null)); }

    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] grantResults){
        super.onRequestPermissionsResult(requestCode,permissions,grantResults);
        boolean ok=grantResults.length>0 && grantResults[0]==PackageManager.PERMISSION_GRANTED;
        if(requestCode==REQ_CAMERA && ok) runUi(this::openCameraNow);
        if(requestCode==REQ_CONTACTS) notifyPermission(ok?"contacts":"contacts_denied");
        if(requestCode==REQ_AUDIO && ok) startSpeechRecognizerNow();
        if(requestCode==REQ_SMS && ok){ String n=getPreferences(0).getString("pending_sms_number",""); String m=getPreferences(0).getString("pending_sms_text",""); getPreferences(0).edit().remove("pending_sms_number").remove("pending_sms_text").apply(); if(!n.isEmpty()) sendSmsDirect(n,m); }
        if(requestCode==REQ_MEDIA && ok){ String q=getPreferences(0).getString("pending_music_query",""); getPreferences(0).edit().remove("pending_music_query").apply(); if(!q.isEmpty()) playLocalMusic(q); }
    }

    void startSpeechRecognizerNow(){
        runUi(()->{
            if(!SpeechRecognizer.isRecognitionAvailable(this)){ notifyPermission("voice_unavailable"); return; }
            if(speech!=null) try{speech.destroy();}catch(Exception ignored){}
            speech=SpeechRecognizer.createSpeechRecognizer(this);
            speech.setRecognitionListener(new RecognitionListener(){
                public void onReadyForSpeech(Bundle b){} public void onBeginningOfSpeech(){} public void onRmsChanged(float r){} public void onBufferReceived(byte[] b){} public void onEndOfSpeech(){}
                public void onError(int e){ runUi(()->web.evaluateJavascript("if(window.inoNativeVoiceError) window.inoNativeVoiceError("+e+");",null)); }
                public void onResults(Bundle b){ ArrayList<String> r=b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION); if(r!=null&&!r.isEmpty()) web.evaluateJavascript("if(window.inoNativeVoiceResult) window.inoNativeVoiceResult("+JSONObject.quote(r.get(0))+");",null); }
                public void onPartialResults(Bundle b){} public void onEvent(int a,Bundle b){}
            });
            Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH); i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,webLanguage()); i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM); i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS,false); speech.startListening(i);
        });
    }
    String webLanguage(){ return getPreferences(0).getString("voice_language","pt-BR"); }
    void stopSpeechRecognizer(){ if(speech!=null){try{speech.stopListening(); speech.cancel(); speech.destroy();}catch(Exception ignored){} speech=null;} }

    @Override public void onBackPressed(){ if(web.canGoBack()) web.goBack(); else super.onBackPressed(); }

    public static class AndroidInterface {
        final MainActivity a; AndroidInterface(MainActivity x){a=x;}
        @JavascriptInterface public String getContacts(){
            if(a.checkSelfPermission(Manifest.permission.READ_CONTACTS)!=PackageManager.PERMISSION_GRANTED){ a.pendingPermissionAction="contacts"; a.runOnUiThread(()->a.requestPermissions(new String[]{Manifest.permission.READ_CONTACTS},REQ_CONTACTS)); return "{\"permissionRequired\":\"contacts\"}"; }
            JSONArray arr=new JSONArray(); LinkedHashSet<String> seen=new LinkedHashSet<>();
            try(android.database.Cursor c=a.getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,new String[]{ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,ContactsContract.CommonDataKinds.Phone.NUMBER},null,null,ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME+" ASC")){
                if(c!=null) while(c.moveToNext()){ String name=c.getString(0), number=c.getString(1); String key=(name==null?"":name.trim().toLowerCase(Locale.ROOT))+"|"+(number==null?"":number.replaceAll("\\s+","")); if(!seen.add(key)) continue; JSONObject o=new JSONObject(); o.put("name",name); o.put("number",number); arr.put(o); }
            }catch(Exception ignored){} return arr.toString();
        }
        @JavascriptInterface public boolean makeCall(String n){ try{a.runUi(()->{try{a.startActivity(new Intent(Intent.ACTION_DIAL,Uri.parse("tel:"+Uri.encode(n))));}catch(Exception ignored){}}); return true;}catch(Exception e){return false;} }
        @JavascriptInterface public boolean sendSMS(String n,String msg){ return a.sendSmsDirect(n,msg); }
        @JavascriptInterface public boolean sendWhatsApp(String n,String msg){ return openWhatsApp(n,msg); }
        @JavascriptInterface public boolean sendMessageAuto(String n,String msg,String channel){ return "whatsapp".equalsIgnoreCase(channel)||"zap".equalsIgnoreCase(channel)?openWhatsApp(n,msg):sendSMS(n,msg); }
        @JavascriptInterface public String sendMessageDetailed(String n,String msg,String channel){
            JSONObject out=new JSONObject();
            try{
                boolean wa="whatsapp".equalsIgnoreCase(channel)||"zap".equalsIgnoreCase(channel);
                if(wa){
                    if(!a.accessibilityEnabled()){openWhatsApp(n,msg);out.put("status","PREPARED_ACCESSIBILITY_REQUIRED");return out.toString();}
                    if(!a.openWhatsAppAndSend(n,msg)){out.put("status","FAILED");return out.toString();}
                    new Handler(Looper.getMainLooper()).postDelayed(()->a.executeAccessibilityAction("SEND_MESSAGE","com.whatsapp","","",msg),1600);
                    out.put("status","SEND_REQUESTED");return out.toString();
                }
                if(a.checkSelfPermission(Manifest.permission.SEND_SMS)!=PackageManager.PERMISSION_GRANTED){a.sendSmsDirect(n,msg);out.put("status","PERMISSION_REQUIRED");return out.toString();}
                out.put("status",a.sendSmsDirect(n,msg)?"SENT":"FAILED");return out.toString();
            }catch(Exception e){out.put("status","FAILED");return out.toString();}
        }
        String normalizeInternationalNumber(String n){ String d=n==null?"":n.replaceAll("[^0-9+]",""); if(d.startsWith("+")) return d.substring(1); if(d.startsWith("00")) return d.substring(2); if(d.startsWith("0")){ String iso=""; try{android.telephony.TelephonyManager tm=(android.telephony.TelephonyManager)a.getSystemService(TELEPHONY_SERVICE); iso=tm.getNetworkCountryIso(); if(iso==null||iso.isEmpty()) iso=tm.getSimCountryIso();}catch(Exception ignored){} String cc=countryCode(iso); if(!cc.isEmpty()) return cc+d.substring(1); } return d; }
        String countryCode(String iso){ if(iso==null)return ""; switch(iso.toLowerCase(Locale.ROOT)){case "mz":return "258";case "gb":return "44";case "pt":return "351";case "fr":return "33";case "us":return "1";case "za":return "27";default:return "";} }
        boolean openWhatsApp(String n,String msg){ try{String digits=normalizeInternationalNumber(n); if(digits.length()<7)return false; String u="https://wa.me/"+digits+"?text="+URLEncoder.encode(msg==null?"":msg,"UTF-8"); Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse(u)); i.setPackage("com.whatsapp"); a.runUi(()->{try{a.startActivity(i);}catch(Exception ignored){}}); return true;}catch(Exception e){return false;} }
        @JavascriptInterface public boolean openWhatsAppChat(String n){return openWhatsApp(n,"");}
        @JavascriptInterface public boolean openPlayStoreSearch(String q){return a.openPlayStoreSearch(q);}
        @JavascriptInterface public String executeAppAction(String name,String json){
            JSONObject out=new JSONObject();
            try{
                ResolveInfo ri=a.resolveInstalledApp(name); if(ri==null){out.put("status","NOT_FOUND");return out.toString();}
                JSONObject p=json==null?new JSONObject():new JSONObject(json); String op=p.optString("operation","ABRIR");
                boolean launched=a.launchApp(name,json); if(!launched){out.put("status","FAILED");return out.toString();}
                if("PESQUISAR".equalsIgnoreCase(op) && !p.optString("query","").isEmpty()){
                    String label=a.norm(a.labelOf(ri)); String pkg=ri.activityInfo.packageName;
                    if(label.contains("youtube")||label.contains("spotify")||label.contains("play store")||label.contains("google play")){out.put("status","OPENED_AND_SEARCH_REQUESTED");return out.toString();}
                    if(a.accessibilityEnabled()) { new Handler(Looper.getMainLooper()).postDelayed(()->a.executeAccessibilityAction("SEARCH",pkg,p.optString("query",""),"",""),1200); out.put("status","OPENED_AND_ACCESSIBILITY_REQUESTED"); }
                    else out.put("status","OPENED_ACCESSIBILITY_REQUIRED");
                    return out.toString();
                }
                if("ENVIAR".equalsIgnoreCase(op) && p.optString("text","").length()>0){
                    String contact=p.optString("targetPerson","");
                    if("com.whatsapp".equals(ri.activityInfo.packageName)){
                        String number=a.findContactNumber(contact);
                        if(number.isEmpty()){out.put("status","CONTACT_NOT_FOUND");return out.toString();}
                        if(!a.accessibilityEnabled()){out.put("status","OPENED_ACCESSIBILITY_REQUIRED");return out.toString();}
                        if(!a.openWhatsAppAndSend(number,p.optString("text",""))){out.put("status","FAILED");return out.toString();}
                        new Handler(Looper.getMainLooper()).postDelayed(()->a.executeAccessibilityAction("SEND_MESSAGE",ri.activityInfo.packageName,"",contact,p.optString("text","")),1600);
                        out.put("status","WHATSAPP_SEND_REQUESTED"); return out.toString();
                    }
                    if(a.accessibilityEnabled()){
                        new Handler(Looper.getMainLooper()).postDelayed(()->a.executeAccessibilityAction("SEND_MESSAGE",ri.activityInfo.packageName,"",contact,p.optString("text","")),1400);
                        out.put("status","OPENED_AND_MESSAGE_REQUESTED"); return out.toString();
                    }
                    out.put("status","OPENED_ACCESSIBILITY_REQUIRED"); return out.toString();
                }
                out.put("status","OPENED"); return out.toString();
            }catch(Exception e){try{out.put("status","FAILED");}catch(Exception ignored){}return out.toString();}
        }
        @JavascriptInterface public boolean openApp(String name,String json){ return a.launchApp(name,json); }
        @JavascriptInterface public boolean openFiles(){try{a.runUi(()->{try{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("*/*");i.addCategory(Intent.CATEGORY_OPENABLE);a.startActivityForResult(i,100);}catch(Exception ignored){}});return true;}catch(Exception e){return false;}}
        @JavascriptInterface public String findAndOpenFile(String name){ return a.findAndOpenFile(name); }
        @JavascriptInterface public String moveFile(String name,String folder){ return a.moveMediaFile(name,folder); }
        @JavascriptInterface public String executeAccessibility(String action,String packageName,String query,String contact,String message){ return a.executeAccessibilityAction(action,packageName,query,contact,message); }
        @JavascriptInterface public boolean requestAccessibility(){ a.requestAccessibility(); return true; }
        @JavascriptInterface public boolean isAccessibilityEnabled(){ return a.accessibilityEnabled(); }
        @JavascriptInterface public String findMusic(String query){
            if(a.checkSelfPermission(Build.VERSION.SDK_INT>=33?Manifest.permission.READ_MEDIA_AUDIO:Manifest.permission.READ_EXTERNAL_STORAGE)!=PackageManager.PERMISSION_GRANTED){
                a.getPreferences(0).edit().putString("pending_music_query",query==null?"":query).apply();
                a.runOnUiThread(()->a.requestPermissions(new String[]{Build.VERSION.SDK_INT>=33?Manifest.permission.READ_MEDIA_AUDIO:Manifest.permission.READ_EXTERNAL_STORAGE},REQ_MEDIA));
                return "{\"status\":\"PERMISSION_REQUIRED\"}";
            }
            return a.findLocalMusic(query);
        }
        @JavascriptInterface public boolean openFile(String name){ return a.findAndOpenFile(name).contains("\"status\":\"OPENED\""); }
        String mimeFor(String name){ String n=name==null?"":name.toLowerCase(Locale.ROOT); if(n.endsWith(".pdf"))return "application/pdf"; if(n.endsWith(".jpg")||n.endsWith(".jpeg"))return "image/jpeg"; if(n.endsWith(".png"))return "image/png"; if(n.endsWith(".mp3"))return "audio/*"; if(n.endsWith(".mp4"))return "video/*"; if(n.endsWith(".txt"))return "text/plain"; return "*/*"; }
        @JavascriptInterface public boolean openGallery(){try{a.runUi(()->{try{Intent i=new Intent(Intent.ACTION_VIEW,android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);a.startActivity(i);}catch(Exception ignored){}});return true;}catch(Exception e){return false;}}
        @JavascriptInterface public boolean openCamera(){ if(a.checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED){a.runOnUiThread(()->a.requestPermissions(new String[]{Manifest.permission.CAMERA},REQ_CAMERA));return true;} a.runOnUiThread(a::openCameraNow); return true; }
        @JavascriptInterface public boolean playMedia(String q){
            if(q==null||q.trim().isEmpty()) return false;
            if(a.checkSelfPermission(Build.VERSION.SDK_INT>=33?Manifest.permission.READ_MEDIA_AUDIO:Manifest.permission.READ_EXTERNAL_STORAGE)!=PackageManager.PERMISSION_GRANTED){
                a.runOnUiThread(()->a.requestPermissions(new String[]{Build.VERSION.SDK_INT>=33?Manifest.permission.READ_MEDIA_AUDIO:Manifest.permission.READ_EXTERNAL_STORAGE},REQ_MEDIA));
                a.getPreferences(0).edit().putString("pending_music_query",q).apply(); return false;
            }
            return a.playLocalMusic(q);
        }
        boolean dummy(){return false;}
        @JavascriptInterface public boolean searchWeb(String q){a.openUrl("https://www.google.com/search?q="+Uri.encode(q));return true;}
        @JavascriptInterface public boolean showFloatingBubble(){ if(!Settings.canDrawOverlays(a)){try{a.startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+a.getPackageName())));}catch(Exception ignored){} return false;} Intent i=new Intent(a,FloatingBubbleService.class); i.setAction("SHOW"); if(Build.VERSION.SDK_INT>=26)a.startForegroundService(i);else a.startService(i); return true; }
        @JavascriptInterface public boolean hideFloatingBubble(){try{a.stopService(new Intent(a,FloatingBubbleService.class));return true;}catch(Exception e){return false;}}
        @JavascriptInterface public boolean setFloatingBubbleState(String state){return true;}
        @JavascriptInterface public boolean setAssistantEnabled(boolean enabled){a.getPreferences(0).edit().putBoolean("enabled",enabled).apply();return true;}
        @JavascriptInterface public boolean speakNative(String text,String lang){ try{ a.runUi(()->{ try{ if(a.tts==null)return; Locale l=Locale.forLanguageTag(lang==null?"pt-BR":lang); a.tts.setLanguage(l); a.tts.speak(text,TextToSpeech.QUEUE_FLUSH,null,"INO_"+System.currentTimeMillis()); }catch(Exception ignored){} }); return true;}catch(Exception e){return false;} }
        @JavascriptInterface public boolean stopSpeech(){ try{ if(a.tts!=null)a.tts.stop(); return true;}catch(Exception e){return false;} }
        @JavascriptInterface public boolean startVoiceAssistant(){ if(a.checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){a.runOnUiThread(()->a.requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},REQ_AUDIO));return true;} a.startSpeechRecognizerNow(); return true; }
        @JavascriptInterface public boolean stopVoiceAssistant(){a.stopSpeechRecognizer();return true;}
        @JavascriptInterface public boolean openAuthUrl(String url){ if(url==null||!url.startsWith("https://")) return false; a.openUrl(url); return true; }
        @JavascriptInterface public String getResearchEndpoint(){ if(BuildConfig.INO_RESEARCH_ENDPOINT!=null&&!BuildConfig.INO_RESEARCH_ENDPOINT.isEmpty()) return BuildConfig.INO_RESEARCH_ENDPOINT; String saved=a.getPreferences(0).getString("research_endpoint",""); if(!saved.isEmpty()) return saved; return BuildConfig.DEBUG?"http://10.0.2.2:8787/api/research":""; }
        @JavascriptInterface public boolean setResearchEndpoint(String endpoint){ if(endpoint==null || !(endpoint.startsWith("https://") || endpoint.startsWith("http://") || endpoint.equals("/api/research"))) return false; a.getPreferences(0).edit().putString("research_endpoint", endpoint).apply(); return true; }
        @JavascriptInterface public String getResearchApiKey(){ return BuildConfig.INO_API_KEY!=null?BuildConfig.INO_API_KEY:""; }
        @JavascriptInterface public boolean setBubbleState(String state){ a.bubbleState(state==null?"pronto":state); return true; }
        @JavascriptInterface public boolean setVoiceLanguage(String lang){ if(lang==null||lang.length()<2)return false; a.getPreferences(0).edit().putString("voice_language",lang).apply(); return true; }
    }
}
