package com.ino.assistant;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.*;

/**
 * Optional, user-authorized UI automation layer for INO.
 * It does not bypass Android security, login screens or permissions.
 * It is intentionally heuristic because third-party app UIs are not standardized.
 */
public class InoAccessibilityService extends AccessibilityService {
    private static InoAccessibilityService instance;
    private static String lastPackage="";

    @Override public void onServiceConnected(){
        instance=this;
        AccessibilityServiceInfo info=new AccessibilityServiceInfo();
        info.eventTypes=AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED|AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED|AccessibilityEvent.TYPE_VIEW_CLICKED;
        info.feedbackType=AccessibilityServiceInfo.FEEDBACK_GENERIC;
        info.notificationTimeout=100;
        info.flags=AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS|AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS;
        setServiceInfo(info);
    }
    @Override public void onAccessibilityEvent(AccessibilityEvent event){
        if(event!=null && event.getPackageName()!=null) lastPackage=event.getPackageName().toString();
    }
    @Override public void onInterrupt(){}
    @Override public void onDestroy(){if(instance==this)instance=null;super.onDestroy();}
    public static boolean isEnabled(){return instance!=null;}

    public static boolean execute(String action,String packageName,String query,String contact,String message){
        if(instance==null)return false;
        return instance.executeInternal(action,packageName,query,contact,message);
    }

    private boolean executeInternal(String action,String packageName,String query,String contact,String message){
        if(packageName!=null&&!packageName.isEmpty()&&!packageName.equals(lastPackage)){
            // The app is normally already in the foreground. Do not navigate blindly.
        }
        String a=action==null?"":action.toUpperCase(Locale.ROOT);
        if("SEARCH".equals(a)) return performSearch(query);
        if("SEND_MESSAGE".equals(a)) return performSendMessage(message);
        if("CLICK".equals(a)) return clickBest(query);
        if("TYPE".equals(a)) return typeIntoFocused(query);
        return false;
    }

    private AccessibilityNodeInfo root(){return getRootInActiveWindow();}

    private boolean performSearch(String query){
        if(TextUtils.isEmpty(query))return false;
        AccessibilityNodeInfo r=root(); if(r==null)return false;
        AccessibilityNodeInfo field=findSearchField(r);
        if(field==null){
            // Try visible labels/buttons that commonly represent search.
            field=findByText(r,new String[]{"pesquisar","pesquisa","buscar","busca","search","find"},true);
        }
        if(field==null)return false;
        if(!field.performAction(AccessibilityNodeInfo.ACTION_CLICK)) field.performAction(AccessibilityNodeInfo.ACTION_FOCUS);
        Bundle b=new Bundle();b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,query);
        boolean typed=field.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT,b);
        if(!typed) typed=typeIntoFocused(query);
        if(!typed)return false;
        // Give the target app a chance to react, then press the search/editor action if available.
        field.performAction(AccessibilityNodeInfo.ACTION_IME_ENTER);
        return true;
    }

    private AccessibilityNodeInfo findSearchField(AccessibilityNodeInfo node){
        if(node==null)return null;
        CharSequence hint=node.getHintText(), desc=node.getContentDescription(), text=node.getText();
        String all=((hint==null?"":hint)+" "+(desc==null?"":desc)+" "+(text==null?"":text)).toLowerCase(Locale.ROOT);
        if(node.isEditable() && (all.contains("pesquis")||all.contains("buscar")||all.contains("search")||all.contains("find")||all.contains("procur"))) return node;
        for(int i=0;i<node.getChildCount();i++){AccessibilityNodeInfo x=findSearchField(node.getChild(i));if(x!=null)return x;}
        return null;
    }

    private AccessibilityNodeInfo findByText(AccessibilityNodeInfo node,String[] words,boolean clickable){
        if(node==null)return null;
        String s=((node.getText()==null?"":node.getText())+" "+(node.getContentDescription()==null?"":node.getContentDescription())).toLowerCase(Locale.ROOT);
        for(String w:words) if(s.contains(w) && (!clickable||node.isClickable())) return node;
        for(int i=0;i<node.getChildCount();i++){AccessibilityNodeInfo x=findByText(node.getChild(i),words,clickable);if(x!=null)return x;}
        return null;
    }

    private boolean typeIntoFocused(String text){
        AccessibilityNodeInfo r=root();if(r==null)return false;
        AccessibilityNodeInfo field=findEditable(r);if(field==null)return false;
        Bundle b=new Bundle();b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,text);return field.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT,b);
    }
    private AccessibilityNodeInfo findEditable(AccessibilityNodeInfo node){
        if(node==null)return null;if(node.isEditable())return node;
        for(int i=0;i<node.getChildCount();i++){AccessibilityNodeInfo x=findEditable(node.getChild(i));if(x!=null)return x;}return null;
    }

    private boolean performSendMessage(String message){
        if(TextUtils.isEmpty(message))return false;
        AccessibilityNodeInfo r=root();if(r==null)return false;
        AccessibilityNodeInfo field=findEditable(r);
        if(field==null)return false;
        Bundle b=new Bundle();b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,message);
        if(!field.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT,b))return false;
        AccessibilityNodeInfo send=findByText(r,new String[]{"enviar","send","mandar"},true);
        if(send==null){
            // Refresh tree after text entry.
            r=root();send=findByText(r,new String[]{"enviar","send","mandar"},true);
        }
        return send!=null && send.performAction(AccessibilityNodeInfo.ACTION_CLICK);
    }

    private boolean clickBest(String label){
        AccessibilityNodeInfo r=root();if(r==null)return false;
        AccessibilityNodeInfo n=findByText(r,new String[]{label},true);return n!=null&&n.performAction(AccessibilityNodeInfo.ACTION_CLICK);
    }
}
