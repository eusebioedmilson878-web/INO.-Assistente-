package com.ino.assistant;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.*;
import android.provider.Settings;
import android.speech.*;
import android.speech.tts.*;
import android.view.*;
import android.widget.*;
import java.util.*;

/** INO V18.4: visual/voice face only. The APK remains the single brain/executor. */
public class FloatingBubbleService extends Service {
    WindowManager wm; View bubble; WindowManager.LayoutParams params;
    TextView face, eyeL, eyeR, mouth; LinearLayout panel;
    SpeechRecognizer recognizer; boolean micEnabled=true, listening=false, speaking=false;
    BroadcastReceiver stateReceiver;
    Handler handler=new Handler(Looper.getMainLooper());

    @Override public void onCreate(){ super.onCreate(); createChannel(); startForeground(77,notification()); registerStateReceiver(); show(); startVoiceLoop(); }
    void registerStateReceiver(){
        stateReceiver=new BroadcastReceiver(){ @Override public void onReceive(Context c,Intent i){ String st=i.getStringExtra("state"); if(st==null)return; applyState(st); } };
        IntentFilter f=new IntentFilter("INO_BUBBLE_STATE"); if(Build.VERSION.SDK_INT>=33) registerReceiver(stateReceiver,f,Context.RECEIVER_NOT_EXPORTED); else registerReceiver(stateReceiver,f);
    }
    void applyState(String st){
        if("falando".equals(st)||"start".equals(st)){ speaking=true; stopVoiceLoop(); }
        else if("pronto".equals(st)||"ouvindo".equals(st)||"dormindo".equals(st)){ speaking=false; if("dormindo".equals(st)){ setFaceColor(Color.rgb(35,35,70)); } else if("ouvindo".equals(st)){ setFaceColor(Color.rgb(20,130,180)); } else { setFaceColor(Color.rgb(70,45,190)); } if(micEnabled&&!listening) handler.postDelayed(()->startVoiceLoop(),450); }
        else if("pesquisando".equals(st)){ setFaceColor(Color.rgb(110,60,210)); }
        else if("executando".equals(st)){ setFaceColor(Color.rgb(80,70,220)); }
        else if("erro".equals(st)){ setFaceColor(Color.rgb(170,45,70)); }
    }
    void setFaceColor(int color){ if(bubble!=null) bubble.setBackground(circle(color)); }
    void createChannel(){ if(Build.VERSION.SDK_INT>=26){ NotificationChannel c=new NotificationChannel("ino_bubble","INO",NotificationManager.IMPORTANCE_LOW); getSystemService(NotificationManager.class).createNotificationChannel(c); } }
    Notification notification(){ Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,"ino_bubble"):new Notification.Builder(this); return b.setContentTitle("INO ativo").setContentText("Rosto flutuante do INO").setSmallIcon(android.R.drawable.ic_dialog_info).setOngoing(true).build(); }

    GradientDrawable circle(int color){ GradientDrawable g=new GradientDrawable(); g.setShape(GradientDrawable.OVAL); g.setColor(color); g.setStroke(2,Color.argb(160,180,210,255)); return g; }
    void show(){
        if(!Settings.canDrawOverlays(this)) return;
        wm=(WindowManager)getSystemService(WINDOW_SERVICE);
        FrameLayout root=new FrameLayout(this); root.setPadding(12,12,12,12); root.setBackground(circle(Color.rgb(70,45,190)));
        LinearLayout faceBox=new LinearLayout(this); faceBox.setOrientation(LinearLayout.VERTICAL); faceBox.setGravity(Gravity.CENTER);
        LinearLayout eyes=new LinearLayout(this); eyes.setGravity(Gravity.CENTER); eyeL=eye(); eyeR=eye(); eyes.addView(eyeL); eyes.addView(space(8)); eyes.addView(eyeR);
        mouth=new TextView(this); mouth.setText("◡"); mouth.setTextColor(Color.WHITE); mouth.setTextSize(18); mouth.setGravity(Gravity.CENTER); faceBox.addView(eyes,new LinearLayout.LayoutParams(-1,45)); faceBox.addView(mouth,new LinearLayout.LayoutParams(-1,32)); root.addView(faceBox,new FrameLayout.LayoutParams(-1,-1));
        root.setOnClickListener(v->togglePanel());
        params=new WindowManager.LayoutParams(180,180,Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT); params.gravity=Gravity.TOP|Gravity.START; params.x=30; params.y=220;
        root.setOnTouchListener(new View.OnTouchListener(){float dx,dy,sx,sy;boolean moved; public boolean onTouch(View v,MotionEvent e){switch(e.getAction()){case MotionEvent.ACTION_DOWN:dx=e.getRawX();dy=e.getRawY();sx=params.x;sy=params.y;moved=false;return true;case MotionEvent.ACTION_MOVE:float mx=e.getRawX()-dx,my=e.getRawY()-dy;if(Math.abs(mx)>8||Math.abs(my)>8)moved=true;params.x=(int)(sx+mx);params.y=(int)(sy+my);clamp();wm.updateViewLayout(root,params);return true;case MotionEvent.ACTION_UP:if(!moved)v.performClick();return true;}return false;}});
        bubble=root; wm.addView(root,params);
    }
    TextView eye(){TextView v=new TextView(this);v.setText("•");v.setTextColor(Color.WHITE);v.setTextSize(30);v.setGravity(Gravity.CENTER);return v;}
    Space space(int w){Space s=new Space(this);s.setLayoutParams(new LinearLayout.LayoutParams(w,1));return s;}
    void clamp(){if(wm==null)return; params.x=Math.max(0,Math.min(params.x,Math.max(0,wm.getDefaultDisplay().getWidth()-params.width)));params.y=Math.max(0,Math.min(params.y,Math.max(0,wm.getDefaultDisplay().getHeight()-params.height)));}

    void togglePanel(){
        if(panel!=null){wm.removeView(panel);panel=null;return;}
        panel=new LinearLayout(this);panel.setOrientation(LinearLayout.HORIZONTAL);panel.setPadding(12,8,12,8);panel.setBackgroundColor(Color.argb(235,25,25,35));
        Button mic=new Button(this);mic.setText(micEnabled?"🎤":"🔇");mic.setOnClickListener(v->{micEnabled=!micEnabled;sendSetting("microphone",String.valueOf(micEnabled));if(micEnabled)startVoiceLoop();else stopVoiceLoop();});
        Button slower=new Button(this);slower.setText("A−");slower.setOnClickListener(v->changeRate(-0.1f)); Button faster=new Button(this);faster.setText("A+");faster.setOnClickListener(v->changeRate(0.1f));
        Button dim=new Button(this);dim.setText("☼");dim.setOnClickListener(v->{params.width=params.height=130;wm.updateViewLayout(bubble,params);}); Button close=new Button(this);close.setText("×");close.setOnClickListener(v->{stopSelf();});
        panel.addView(mic);panel.addView(slower);panel.addView(faster);panel.addView(dim);panel.addView(close);
        WindowManager.LayoutParams pp=new WindowManager.LayoutParams(-2,80,Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT);pp.gravity=Gravity.TOP|Gravity.START;pp.x=params.x;pp.y=params.y+params.height+8;wm.addView(panel,pp);
    }
    float rate=1f; void changeRate(float d){rate=Math.max(.6f,Math.min(1.5f,rate+d));sendSetting("speech_rate",String.valueOf(rate));}
    void sendSetting(String k,String v){Intent i=new Intent("INO_BUBBLE_SETTING");i.setPackage(getPackageName());i.putExtra("key",k);i.putExtra("value",v);sendBroadcast(i);}

    void startVoiceLoop(){
        if(!micEnabled||speaking||listening||checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED||!SpeechRecognizer.isRecognitionAvailable(this))return;
        handler.post(()->{try{recognizer=SpeechRecognizer.createSpeechRecognizer(this);recognizer.setRecognitionListener(new RecognitionListener(){public void onReadyForSpeech(Bundle b){listening=true;state("ouvindo");}public void onBeginningOfSpeech(){}public void onRmsChanged(float r){}public void onBufferReceived(byte[] b){}public void onEndOfSpeech(){listening=false;}public void onPartialResults(Bundle b){}public void onEvent(int t,Bundle b){}public void onError(int e){listening=false;if(micEnabled&&!speaking)handler.postDelayed(()->startVoiceLoop(),500);}public void onResults(Bundle b){listening=false;ArrayList<String> rs=b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);if(rs!=null&&!rs.isEmpty())handleVoice(rs.get(0));if(micEnabled&&!speaking)handler.postDelayed(()->startVoiceLoop(),300);}});Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,"pt-BR");i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS,false);recognizer.startListening(i);}catch(Exception e){handler.postDelayed(()->startVoiceLoop(),1000);}});
    }
    void handleVoice(String heard){String n=heard==null?"":heard.trim();if(n.isEmpty())return;String low=n.toLowerCase(Locale.ROOT);int p=low.indexOf("ino");if(p<0)return;String command=n.substring(p+3).trim();if(command.isEmpty()){sendBroadcast(new Intent("INO_BUBBLE_WAKE").setPackage(getPackageName()));state("pronto");return;}sendBroadcast(new Intent("INO_BUBBLE_COMMAND").setPackage(getPackageName()).putExtra("text",command));state("executando");}
    void stopVoiceLoop(){try{if(recognizer!=null){recognizer.cancel();recognizer.destroy();}}catch(Exception ignored){}recognizer=null;listening=false;}
    void state(String s){Intent i=new Intent("INO_BUBBLE_STATE");i.setPackage(getPackageName());i.putExtra("state",s);sendBroadcast(i);}
    @Override public int onStartCommand(Intent i,int f,int id){if(bubble==null)show();if("SPEAKING".equals(i==null?"":i.getAction())){speaking=true;stopVoiceLoop();}else if("READY".equals(i==null?"":i.getAction())){speaking=false;startVoiceLoop();}return START_STICKY;}
    @Override public void onDestroy(){if(stateReceiver!=null){try{unregisterReceiver(stateReceiver);}catch(Exception ignored){}}stopVoiceLoop();if(wm!=null&&bubble!=null)try{wm.removeView(bubble);}catch(Exception ignored){}if(panel!=null)try{wm.removeView(panel);}catch(Exception ignored){}bubble=null;panel=null;super.onDestroy();}
    @Override public IBinder onBind(Intent i){return null;}
}
