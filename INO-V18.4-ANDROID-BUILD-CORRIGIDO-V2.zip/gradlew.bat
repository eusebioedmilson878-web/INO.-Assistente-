@echo off
setlocal
set ROOT=%~dp0
set GRADLE_VERSION=8.7
set CACHE=%ROOT%.gradle-bootstrap
set DIST=%CACHE%\gradle-%GRADLE_VERSION%
if exist "%DIST%\bin\gradle.bat" goto RUN
where gradle >nul 2>nul
if %ERRORLEVEL% EQU 0 goto SYSTEM
if not exist "%CACHE%" mkdir "%CACHE%"
set ZIP=%CACHE%\gradle-%GRADLE_VERSION%-bin.zip
powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -UseBasicParsing 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile '%ZIP%'"
powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -Force '%ZIP%' '%CACHE%'"
goto RUN
:SYSTEM
gradle %*
exit /b %ERRORLEVEL%
:RUN
call "%DIST%\bin\gradle.bat" %*
exit /b %ERRORLEVEL%
