INO V18.4 — ANDROID

Projeto Android nativo do INO.

Principais capacidades:
- resolução dinâmica de aplicativos lançáveis;
- Play Store/YouTube/Spotify;
- contactos e SMS;
- WhatsApp com preparação e automação opcional por AccessibilityService autorizado;
- pesquisa e reprodução de música local;
- procura/abertura de ficheiros pelo MediaStore quando acessível;
- transferência de itens MediaStore no Android 10+ quando suportado;
- voz nativa e TTS;
- bolha flutuante.

Para pesquisa dentro de aplicativos de terceiros, o usuário precisa ativar INO Automação em Configurações > Acessibilidade. Isso não garante todas as interfaces.

Compilação: executar assembleDebug numa máquina com Android SDK e Gradle disponíveis. Este ambiente de desenvolvimento não possui esses componentes, portanto não foi declarado um APK compilado aqui.


FONTES REAIS E REGISTRO
O ficheiro INO-SOURCES-REAL.json lista apenas conectores reais implementados. A arquitetura de 300 posições não é apresentada como 300 conexões ativas.
